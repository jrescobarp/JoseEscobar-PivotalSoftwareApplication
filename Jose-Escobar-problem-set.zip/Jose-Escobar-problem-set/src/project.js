function Project() {
	this.iter = 3;
}
var itArr = [0,0,0];//new Array();
Project.prototype.addIteration = function(iteration) {
	// window.alert(iteration.totalPoints());
	var mod =(this.iter%3);//4)-1;
	this.iter += 1;
	itArr[mod] = iteration.totalPoints();
}

Project.prototype.velocity = function() {
	//add up values depending on mod.
	var vel = 0;
	//if iterations > 3 just divide by 3
	for (var i = 0; i < 3; i++) {
		vel += itArr[i];
		}
	if(this.iter > 6){
		vel = vel/3.0
		return vel;
	}
	// // else check # of iterations
	else{
		vel = vel/(this.iter-3);
		return vel;
	}
}


